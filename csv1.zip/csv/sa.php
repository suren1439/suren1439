<!Doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>How to Import and Export CSV Files Using PHP and MySQL</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body style="background-color:#5ab9ea">
<div class="container" style="margin-top:50px">
<CENTER>
<h1>LIST OF DETAILS:</h1><br>
</CENTER>
  <div class="row">
    <!--- this form is for the Import data--->
    <form action="import_data.php" method="POST" enctype="multipart/form-data" style="margin-left: 500px;">
      <div class="form-group">
      </div>
      <div class="form-group">
      </div>
    </form>  
    <table class="table table-striped" style="background-color:#88bdbc" data-page-length ='100'> 
      <thead>
        <tr style="background-color:red">
          <th>S.No</th>
          <th>Emp_Id</th>
          <th>Gender</th>
          <th>Email</th>
          <th>Age</th>
          <th>User Name</th>
          <th>Password</th>
        </tr>
      </thead>
      <?php
          // include database connectivity 

          include_once('config.php');

          // fetch data from users table 

          $query  = "SELECT * FROM users";
          $result = mysqli_query($con, $query);
          if (mysqli_num_rows($result) > 0) {
            while ($data = mysqli_fetch_assoc($result)) {
          ?>
          <tr>
            <td><?php echo $data['S.No']?></td>
            <td><?php echo $data['Emp_ID']?></td>
            <td><?php echo $data['Gender']?></td>
            <td><?php echo $data['Email']?></td>
            <td><?php echo $data['Age']?></td>
            <td><?php echo $data['User_Name']?></td>
            <td><?php echo MD5($data['Password'])?></td>
          </tr>
        <?php } } ?> 
    </table>
  </div>
  <form action="index.php" method="POST" enctype="multipart/form-data" style="margin-left: 500px;">
      <div class="form-group"> 
      </div>
      <div class="form-group">
        <input type="submit" name="import" class="btn btn-primary" value="Back">  
      </div>
    </form>  

    
</body>
</html>